CREATE TRIGGER newsru_OnInsert
BEFORE INSERT ON newsru
FOR EACH ROW
  SET NEW.input_date = NOW();
